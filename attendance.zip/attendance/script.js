function cal()
        {
            
            var d=parseInt(document.getElementById("days").value);
            var m=parseInt(document.getElementById("mon").value);
            var t=parseInt(document.getElementById("tue").value);
            var w=parseInt(document.getElementById("wed").value);
            var th=parseInt(document.getElementById("thur").value);
            var f=parseInt(document.getElementById("fri").value);
            var period=m+t+w+th+f;
            var week=d/5;
            var total=week*period;
            var per=(20/100)*total;
            per=per-20;
            var w=per/5;
            document.getElementById("result").innerText = "you can be absent for maximum :" + parseInt(per) + " periods\n (or) \n"+ w + " days";
        }